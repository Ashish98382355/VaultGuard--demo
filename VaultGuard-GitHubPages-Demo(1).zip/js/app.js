/* ===== VaultGuard – Main App Logic ===== */

/* ---- State ---- */
const state = {
  isPro: false,
  lockedApps: new Set(),
  pinCode: '1234',
  pinBuffer: [],
  patternNodes: [],
  patternDrawing: false,
  patternDots: [],
  patternPath: [],
  currentSection: 'dashboard',
  vaultPhotos: [],
  activityLog: [],
  fingerprintRegistered: true,
};

/* ---- Apps list ---- */
const appList = [
  { id: 1, name: 'WhatsApp',   icon: '💬', color: '#25D366' },
  { id: 2, name: 'Instagram',  icon: '📸', color: '#E1306C' },
  { id: 3, name: 'Gmail',      icon: '📧', color: '#EA4335' },
  { id: 4, name: 'YouTube',    icon: '▶️',  color: '#FF0000' },
  { id: 5, name: 'Facebook',   icon: '👍', color: '#1877F2' },
  { id: 6, name: 'Snapchat',   icon: '👻', color: '#FFFC00' },
  { id: 7, name: 'Twitter',    icon: '🐦', color: '#1DA1F2' },
  { id: 8, name: 'TikTok',     icon: '🎵', color: '#010101' },
  { id: 9, name: 'Gallery',    icon: '🖼️',  color: '#7C6AFF' },
  { id:10, name: 'Messages',   icon: '💬', color: '#00B4D8' },
  { id:11, name: 'Contacts',   icon: '👤', color: '#51CF66' },
  { id:12, name: 'Settings',   icon: '⚙️',  color: '#8B9FC0' },
  { id:13, name: 'Play Store', icon: '🏪', color: '#01875F' },
  { id:14, name: 'Chrome',     icon: '🌐', color: '#4285F4' },
  { id:15, name: 'Camera',     icon: '📷', color: '#FF6B6B' },
  { id:16, name: 'Calendar',   icon: '📅', color: '#FFA94D' },
  { id:17, name: 'Maps',       icon: '🗺️',  color: '#34A853' },
  { id:18, name: 'Phone',      icon: '📞', color: '#4CAF50' },
  { id:19, name: 'Calculator', icon: '🔢', color: '#607D8B' },
  { id:20, name: 'Files',      icon: '📁', color: '#FF9800' },
];

/* ---- Init ---- */
document.addEventListener('DOMContentLoaded', () => {
  renderApps(appList);
  initPattern();
  initTabs();
  initNav();
  updateStats();
});

/* ==============================
   LOCK SCREEN
   ============================== */
function initTabs() {
  document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const tab = btn.dataset.tab;
      document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
      document.querySelectorAll('.auth-panel').forEach(p => p.classList.remove('active'));
      btn.classList.add('active');
      document.getElementById(`panel-${tab}`).classList.add('active');
    });
  });
}

/* -- Fingerprint simulation -- */
function simulateFingerprint() {
  const btn = document.getElementById('fpScanBtn');
  const status = document.getElementById('fpStatus');
  const ring = document.getElementById('fingerprintRing');

  btn.disabled = true;
  btn.querySelector('span').textContent = 'SCANNING…';
  ring.style.animation = 'none';
  ring.style.filter = 'drop-shadow(0 0 20px rgba(0,245,196,1))';

  status.textContent = '';
  status.className = 'auth-status';

  setTimeout(() => {
    const success = Math.random() > 0.15; // 85% success
    if (success) {
      status.textContent = '✓ Fingerprint Matched – Access Granted';
      status.classList.add('success');
      ring.style.filter = 'drop-shadow(0 0 24px rgba(81,207,102,1))';
      addActivity('Fingerprint unlock – Success', 'success');
      setTimeout(unlockApp, 900);
    } else {
      status.textContent = '✗ Fingerprint Not Recognized – Try Again';
      status.classList.add('error');
      ring.style.filter = 'drop-shadow(0 0 24px rgba(255,107,107,1))';
      btn.disabled = false;
      btn.querySelector('span').textContent = 'SCAN FINGERPRINT';
      setTimeout(() => { ring.style.filter = ''; }, 1400);
    }
  }, 1800);
}

/* -- PIN -- */
function pinInput(digit) {
  if (state.pinBuffer.length >= 4) return;
  state.pinBuffer.push(digit);
  const dot = document.getElementById(`dot${state.pinBuffer.length - 1}`);
  dot.classList.add('filled');

  if (state.pinBuffer.length === 4) {
    const entered = state.pinBuffer.join('');
    setTimeout(() => {
      if (entered === state.pinCode) {
        addActivity('PIN unlock – Success', 'success');
        unlockApp();
      } else {
        showToast('Incorrect PIN', 'error');
        state.pinBuffer = [];
        document.querySelectorAll('.pin-dot').forEach(d => {
          d.classList.remove('filled');
          d.style.background = 'rgba(255,107,107,0.4)';
          setTimeout(() => { d.style.background = ''; }, 500);
        });
      }
    }, 250);
  }
}

function pinDelete() {
  if (!state.pinBuffer.length) return;
  state.pinBuffer.pop();
  document.querySelectorAll('.pin-dot').forEach((d, i) => {
    d.classList.toggle('filled', i < state.pinBuffer.length);
  });
}

/* -- Pattern -- */
function initPattern() {
  const canvas = document.getElementById('patternCanvas');
  const ctx = canvas.getContext('2d');
  const size = 220;
  const dotR = 8;
  const cols = 3; const rows = 3;
  const spacing = size / (cols + 1);

  // Build dot positions
  state.patternDots = [];
  for (let r = 0; r < rows; r++) {
    for (let c = 0; c < cols; c++) {
      state.patternDots.push({ x: spacing * (c + 1), y: spacing * (r + 1), id: r * cols + c });
    }
  }

  function draw(mx, my) {
    ctx.clearRect(0, 0, size, size);
    // Draw lines
    ctx.strokeStyle = 'rgba(0,245,196,0.6)';
    ctx.lineWidth = 3;
    ctx.lineCap = 'round';
    if (state.patternPath.length > 1) {
      ctx.beginPath();
      state.patternPath.forEach((id, i) => {
        const d = state.patternDots[id];
        if (i === 0) ctx.moveTo(d.x, d.y); else ctx.lineTo(d.x, d.y);
      });
      ctx.stroke();
    }
    // Current finger line
    if (state.patternDrawing && state.patternPath.length) {
      const last = state.patternDots[state.patternPath[state.patternPath.length - 1]];
      ctx.beginPath(); ctx.moveTo(last.x, last.y);
      ctx.lineTo(mx, my); ctx.stroke();
    }
    // Draw dots
    state.patternDots.forEach(d => {
      const selected = state.patternPath.includes(d.id);
      ctx.beginPath(); ctx.arc(d.x, d.y, dotR, 0, Math.PI * 2);
      ctx.fillStyle = selected ? 'rgba(0,245,196,0.9)' : 'rgba(139,159,192,0.5)';
      ctx.fill();
      if (selected) {
        ctx.beginPath(); ctx.arc(d.x, d.y, dotR + 5, 0, Math.PI * 2);
        ctx.strokeStyle = 'rgba(0,245,196,0.3)'; ctx.lineWidth = 2; ctx.stroke();
      }
    });
  }

  function getHit(x, y) {
    return state.patternDots.find(d => Math.hypot(d.x - x, d.y - y) < 22);
  }

  function getPos(e) {
    const rect = canvas.getBoundingClientRect();
    const t = e.touches ? e.touches[0] : e;
    return { x: t.clientX - rect.left, y: t.clientY - rect.top };
  }

  canvas.addEventListener('mousedown', e => { state.patternDrawing = true; state.patternPath = []; });
  canvas.addEventListener('touchstart', e => { e.preventDefault(); state.patternDrawing = true; state.patternPath = []; }, {passive:false});

  canvas.addEventListener('mousemove', e => {
    if (!state.patternDrawing) return;
    const {x, y} = getPos(e);
    const hit = getHit(x, y);
    if (hit && !state.patternPath.includes(hit.id)) state.patternPath.push(hit.id);
    draw(x, y);
  });
  canvas.addEventListener('touchmove', e => {
    e.preventDefault();
    if (!state.patternDrawing) return;
    const {x, y} = getPos(e);
    const hit = getHit(x, y);
    if (hit && !state.patternPath.includes(hit.id)) state.patternPath.push(hit.id);
    draw(x, y);
  }, {passive:false});

  function end() {
    if (!state.patternDrawing) return;
    state.patternDrawing = false;
    if (state.patternPath.length >= 4) {
      addActivity('Pattern unlock – Success', 'success');
      draw(0, 0);
      setTimeout(unlockApp, 600);
    } else if (state.patternPath.length > 0) {
      showToast('Connect at least 4 dots', 'error');
      clearPattern();
    }
  }
  canvas.addEventListener('mouseup', end);
  canvas.addEventListener('touchend', end);
  draw(0, 0);
}

function clearPattern() {
  state.patternPath = [];
  const canvas = document.getElementById('patternCanvas');
  const ctx = canvas.getContext('2d');
  ctx.clearRect(0, 0, 220, 220);
  // Redraw dots only
  const size = 220; const cols = 3; const spacing = size / 4; const dotR = 8;
  state.patternDots.forEach(d => {
    ctx.beginPath(); ctx.arc(d.x, d.y, dotR, 0, Math.PI * 2);
    ctx.fillStyle = 'rgba(139,159,192,0.5)'; ctx.fill();
  });
}

/* -- Unlock/Lock -- */
function unlockApp() {
  const ls = document.getElementById('lockScreen');
  ls.classList.remove('active');
  ls.classList.add('hidden');
  setTimeout(() => {
    document.getElementById('mainApp').classList.remove('hidden');
    updateStats();
  }, 500);
}

function lockApp() {
  document.getElementById('mainApp').classList.add('hidden');
  const ls = document.getElementById('lockScreen');
  ls.classList.remove('hidden');
  ls.classList.add('active');
  // Reset PIN
  state.pinBuffer = [];
  document.querySelectorAll('.pin-dot').forEach(d => d.classList.remove('filled'));
  // Reset FP status
  const st = document.getElementById('fpStatus');
  st.textContent = ''; st.className = 'auth-status';
  document.getElementById('fpScanBtn').disabled = false;
  document.getElementById('fpScanBtn').querySelector('span').textContent = 'SCAN FINGERPRINT';
}

/* ==============================
   APP LOCKER
   ============================== */
function renderApps(list) {
  const grid = document.getElementById('appsGrid');
  if (!grid) return;
  grid.innerHTML = '';
  const maxFree = 5;
  list.forEach((app, idx) => {
    const isLocked = state.lockedApps.has(app.id);
    const isPro = state.isPro;
    const isDisabled = !isPro && state.lockedApps.size >= maxFree && !isLocked;

    const card = document.createElement('div');
    card.className = 'app-card';
    card.innerHTML = `
      <div class="app-icon" style="background:${app.color}22">${app.icon}</div>
      <span class="app-name">${app.name}</span>
      <div class="app-lock-toggle">
        <label class="toggle-switch" title="${isDisabled ? 'Upgrade to PRO to lock more apps' : ''}">
          <input type="checkbox" ${isLocked ? 'checked' : ''} ${isDisabled ? 'disabled' : ''}
            onchange="toggleAppLock(${app.id}, this)"/>
          <span class="slider"></span>
        </label>
      </div>
      ${isLocked ? '<span class="app-locked-badge">LOCKED</span>' : ''}
    `;
    grid.appendChild(card);
  });
}

function filterApps(query) {
  const filtered = appList.filter(a => a.name.toLowerCase().includes(query.toLowerCase()));
  renderApps(filtered);
}

function toggleAppLock(id, el) {
  if (!state.isPro && !state.lockedApps.has(id) && state.lockedApps.size >= 5) {
    el.checked = false;
    showUpgrade();
    return;
  }
  if (el.checked) state.lockedApps.add(id);
  else state.lockedApps.delete(id);
  renderApps(appList);
  updateStats();
}

/* ==============================
   NAV & SECTIONS
   ============================== */
function initNav() {
  document.querySelectorAll('.nav-item').forEach(item => {
    item.addEventListener('click', e => {
      e.preventDefault();
      const sec = item.dataset.section;
      document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
      document.querySelectorAll('.section').forEach(s => s.classList.remove('active'));
      item.classList.add('active');
      document.getElementById(`section-${sec}`).classList.add('active');
      document.getElementById('sectionTitle').textContent =
        sec.charAt(0).toUpperCase() + sec.slice(1);
      state.currentSection = sec;
    });
  });
}

/* ==============================
   BIOMETRIC TOGGLES
   ============================== */
function toggleBio(type, el) {
  const status = document.getElementById(`bio-${type}-status`);
  if (status) {
    status.textContent = el.checked ? 'Active' : 'Inactive';
    status.className = 'bio-status' + (el.checked ? ' active' : '');
  }
  showToast(`${capitalize(type)} ${el.checked ? 'enabled' : 'disabled'}`, 'info');
}

function checkPro(el) {
  if (!state.isPro) {
    el.checked = false;
    showUpgrade();
  }
}
function checkProBtn() {
  if (!state.isPro) showUpgrade();
}

/* ==============================
   UPGRADE MODAL
   ============================== */
function showUpgrade() { document.getElementById('upgradeModal').classList.add('open'); }
function closeUpgrade() { document.getElementById('upgradeModal').classList.remove('open'); }

function activatePro() {
  state.isPro = true;
  const badge = document.getElementById('planBadge');
  badge.textContent = 'PRO';
  badge.className = 'plan-badge pro';
  document.querySelector('.upgrade-btn').textContent = '✓ PRO Active';
  document.querySelector('.upgrade-btn').style.background = 'linear-gradient(135deg,#ffd700,#e67e00)';
  closeUpgrade();
  showToast('🎉 VaultGuard PRO Activated!', 'success');
  renderApps(appList);
}

/* ==============================
   VAULT
   ============================== */
function vaultUploadClick() {
  if (!state.isPro) { showUpgrade(); return; }
  document.getElementById('vaultFileInput').click();
}

function vaultAddPhotos(input) {
  const files = Array.from(input.files);
  const grid = document.getElementById('vaultGrid');
  files.forEach(file => {
    const reader = new FileReader();
    reader.onload = e => {
      const img = document.createElement('img');
      img.src = e.target.result;
      img.style.cssText = 'width:100%;height:120px;object-fit:cover;border-radius:10px;border:1px solid var(--border)';
      grid.appendChild(img);
      state.vaultPhotos.push(e.target.result);
    };
    reader.readAsDataURL(file);
  });
  showToast(`${files.length} photo(s) added to vault`, 'success');
}

/* ==============================
   STATS & ACTIVITY
   ============================== */
function updateStats() {
  const el = document.getElementById('lockedAppsCount');
  if (el) el.textContent = state.lockedApps.size;
}

function addActivity(text, type) {
  state.activityLog.unshift({ text, type, time: 'Just Now' });
  const list = document.getElementById('activityList');
  if (!list) return;
  const item = document.createElement('div');
  item.className = 'activity-item';
  item.innerHTML = `
    <span class="a-icon ${type}">${type === 'success' ? '✓' : '✗'}</span>
    <span class="a-text">${text}</span>
    <span class="a-time">Just Now</span>
  `;
  list.insertBefore(item, list.firstChild);
  if (list.children.length > 6) list.removeChild(list.lastChild);
}

/* ==============================
   SETTINGS ACTIONS
   ============================== */
function exportSettings() {
  const settings = {
    lockedApps: [...state.lockedApps],
    isPro: state.isPro,
    pinCode: '****',
    exportedAt: new Date().toISOString(),
  };
  const blob = new Blob([JSON.stringify(settings, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a'); a.href = url; a.download = 'vaultguard-settings.json';
  a.click(); URL.revokeObjectURL(url);
  showToast('Settings exported', 'success');
}

function resetSettings() {
  if (!confirm('Reset all settings? This cannot be undone.')) return;
  state.lockedApps.clear();
  state.isPro = false;
  renderApps(appList);
  updateStats();
  showToast('Settings reset to defaults', 'info');
}

function changeTheme(theme) {
  document.body.className = theme === 'light' ? 'theme-light' : theme === 'amoled' ? 'theme-amoled' : '';
}

/* ==============================
   TOAST
   ============================== */
function showToast(msg, type = 'info') {
  const t = document.getElementById('toast');
  t.textContent = msg;
  t.className = `toast ${type} show`;
  clearTimeout(t._timer);
  t._timer = setTimeout(() => { t.className = 'toast'; }, 3000);
}

/* ==============================
   HELPERS
   ============================== */
function capitalize(s) { return s.charAt(0).toUpperCase() + s.slice(1); }

// Close modal on overlay click
document.getElementById('upgradeModal').addEventListener('click', function(e) {
  if (e.target === this) closeUpgrade();
});
